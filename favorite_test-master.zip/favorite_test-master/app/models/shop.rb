class Shop < ApplicationRecord
  has_many :products
end
