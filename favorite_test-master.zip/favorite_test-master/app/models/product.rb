class Product < ApplicationRecord
  belongs_to :shop
end
